# database-connect
A single Package for all the database connectivities  ( E.g : MySQL, MongoDb, Cassandra)

# How to Use

* install latest package

> * in jupyter notebook - 

```bash
    !pip install database-connect
```

> * in command prompt - 

```bash
    pip install database-connect